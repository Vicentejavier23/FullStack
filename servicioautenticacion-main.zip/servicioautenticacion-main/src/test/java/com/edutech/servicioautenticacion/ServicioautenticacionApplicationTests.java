package com.edutech.servicioautenticacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioautenticacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
