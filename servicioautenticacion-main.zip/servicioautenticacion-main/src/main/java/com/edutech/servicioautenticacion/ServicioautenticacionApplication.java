package com.edutech.servicioautenticacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicioautenticacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicioautenticacionApplication.class, args);
	}

}
