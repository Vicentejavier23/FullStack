package com.edutech.serviciosoporte;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiciosoporteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiciosoporteApplication.class, args);
	}

}
